package com.example.aplikasipcs.response.login

data class Data(
    val admin:Admin,
    val token:String
)

