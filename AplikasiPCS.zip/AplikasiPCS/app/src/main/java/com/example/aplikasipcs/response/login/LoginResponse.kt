package com.example.aplikasipcs.response.login

data class LoginResponse(
    val success:Boolean,
    val message:String,
    val data:Data
)
